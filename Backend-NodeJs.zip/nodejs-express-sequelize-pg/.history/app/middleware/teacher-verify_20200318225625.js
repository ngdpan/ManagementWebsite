

const db = require("../models");
const Account = db.account;
const Op = db.Sequelize.Op;

// module.exports= (req, res, next) => {
  
//   Account.findByPk(req.account_id)
//     .then(user => {
//       user.getRoles().then(account => {
//         for(let i=0; i<account.length; i++){
//           console.log(account[i].account_type);
//           if(account[i].account_type.toUpperCase() === "ADMIN"){
//             next();
//             return;
//           }
//         }
        
//         res.status(403).send("Require Admin Role!");
//         return;
//       })
//     })
// }


module.exports= (req, res, next) => {
  // -> Check Username is already in use
  Account.findOne({
    where: {
      username: req.body.username,
      account_type:'admin'
    } 
  }).then(user => {
    if(!user){
      res.status(400).send("Fail -> Not allowed user type!");
      return;

    }
        
    next();
  });

}



  
