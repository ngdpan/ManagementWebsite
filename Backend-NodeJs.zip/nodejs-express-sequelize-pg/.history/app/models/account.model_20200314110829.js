
module.exports = (sequelize, Sequelize) => {
  const Account = sequelize.define("account", {
    account_id:{
      type:Sequelize.UUID,
      defaultValue: Sequelize.UUIDV1,
      allowNull: false,
      primaryKey: true
    },
    username:{
      type:Sequelize.STRING
    }
  ,password:{
    type:Sequelize.STRING
  } 
  ,teacher_id:{
    type:Sequelize.INTEGER
  }
  ,account_type:{
    type:Sequelize.STRING
  }
}
  ,{ freezeTableName: true,
    timestamps: false
  });
return Account;
 
};