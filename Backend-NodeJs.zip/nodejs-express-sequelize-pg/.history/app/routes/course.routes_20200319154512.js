module.exports = app => {
  const course = require("../controllers/course.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new 
  router.post("/",[], course.create);

  // Retrieve all 
  router.get("/", [checkAuth],course.findAll);

  // // Retrieve all published 
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single  with id
  router.get("/:id",[checkAuth], course.findOne);

  // Update a with id
  router.put("/:id",[checkAuth,adminVerify], course.update);

  // Delete a with id
  router.delete("/:id",[checkAuth,adminVerify], course.delete);

  // Create a new 
  router.delete("/",[checkAuth,adminVerify], course.deleteAll);

  app.use('/api/course', router);
};
