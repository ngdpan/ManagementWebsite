module.exports = app => {
  const student = require("../controllers/student.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/",[checkAuth,adminVerify,teacherVerify], student.create);

  // Retrieve all Tutorials
  router.get("/",[checkAuth,adminVerify,teacherVerify], student.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", [checkAuth,adminVerify,teacherVerify],student.findOne);

  // Update a Tutorial with id
  router.put("/:id",[checkAuth,adminVerify,teacherVerify], student.update);

  // Delete a Tutorial with id
  router.delete("/:id",[checkAuth,adminVerify,teacherVerify], student.delete);

  // Create a new Tutorial
  router.delete("/",[checkAuth,adminVerify,teacherVerify], student.deleteAll);

  app.use('/api/student', router);
};
