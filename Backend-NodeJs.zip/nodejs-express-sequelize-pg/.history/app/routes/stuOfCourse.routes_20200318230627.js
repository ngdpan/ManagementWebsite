module.exports = app => {
  const stuOfCourse = require("../controllers/stuOfCourse.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new 
  router.post("/",[checkAuth,adminVerify], stuOfCourse.create);

  // Retrieve all 
  router.get("/",[checkAuth], stuOfCourse.findAll);

  // // Retrieve all published 
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single  with id
  router.get("/:id",[checkAuth,adminVerify], stuOfCourse.findOne);

  // Update a with id
  router.put("/:id",[checkAuth,adminVerify], stuOfCourse.update);

  // Delete a with id
  router.delete("/:id", [checkAuth,adminVerify],stuOfCourse.delete);

  // Delete a new 
  router.delete("/",[checkAuth,adminVerify], stuOfCourse.deleteAll);

  app.use('/api/studentofcourse', router);
};
