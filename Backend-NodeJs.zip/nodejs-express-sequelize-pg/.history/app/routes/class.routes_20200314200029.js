module.exports = app => {
  const class_room = require("../controllers/class.controller.js");
  const checkAuth=require('../middleware/check-auth');
  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/",checkAuth, class_room.create);

  // Retrieve all Tutorials
  router.get("/",checkAuth, class_room.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id",checkAuth, class_room.findOne);

  // Update a Tutorial with id
  router.put("/:id",checkAuth, class_room.update);

  // Delete a Tutorial with id
  router.delete("/:id",checkAuth, class_room.delete);

  // Create a new Tutorial
  router.delete("/",checkAuth, class_room.deleteAll);

  app.use('/api/class', router);
};
