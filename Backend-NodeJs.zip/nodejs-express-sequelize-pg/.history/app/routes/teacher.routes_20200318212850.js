module.exports = app => {
  const teacher = require("../controllers/teacher.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/", [checkAuth,adminVerify,teacherVerify],teacher.create);

  // Retrieve all Tutorials
  router.get("/", [checkAuth,adminVerify,teacherVerify],teacher.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", [checkAuth,adminVerify,teacherVerify],teacher.findOne);

  // Update a Tutorial with id
  router.put("/:id", [checkAuth,adminVerify,teacherVerify],teacher.update);

  // Delete a Tutorial with id
  router.delete("/:id", [checkAuth,adminVerify,teacherVerify],teacher.delete);

  // Create a new Tutorial
  router.delete("/",[checkAuth,adminVerify,teacherVerify], teacher.deleteAll);

  app.use('/api/teacher', router);
};
