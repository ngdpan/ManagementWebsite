module.exports = app => {
  const stuOfCourse = require("../controllers/stuOfCourse.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/",[checkAuth,adminVerify,teacherVerify], stuOfCourse.create);

  // Retrieve all Tutorials
  router.get("/",[checkAuth,adminVerify,teacherVerify], stuOfCourse.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id",[checkAuth,adminVerify,teacherVerify], stuOfCourse.findOne);

  // Update a Tutorial with id
  router.put("/:id",[checkAuth,adminVerify,teacherVerify], stuOfCourse.update);

  // Delete a Tutorial with id
  router.delete("/:id", [checkAuth,adminVerify,teacherVerify],stuOfCourse.delete);

  // Create a new Tutorial
  router.delete("/",[checkAuth,adminVerify,teacherVerify], stuOfCourse.deleteAll);

  app.use('/api/studentofcourse', router);
};
