module.exports = app => {
  const teaOfCourse = require("../controllers/teaOfCourse.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/", [checkAuth,adminVerify,teacherVerify],teaOfCourse.create);

  // Retrieve all Tutorials
  router.get("/", [checkAuth,adminVerify,teacherVerify],teaOfCourse.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", [checkAuth,adminVerify,teacherVerify],teaOfCourse.findOne);

  // Update a Tutorial with id
  router.put("/:id",[checkAuth,adminVerify,teacherVerify] ,teaOfCourse.update);

  // Delete a Tutorial with id
  router.delete("/:id",[checkAuth,adminVerify,teacherVerify], teaOfCourse.delete);

  // Create a new Tutorial
  router.delete("/", [checkAuth,adminVerify,teacherVerify],teaOfCourse.deleteAll);

  app.use('/api/teacherofcourse', router);
};
