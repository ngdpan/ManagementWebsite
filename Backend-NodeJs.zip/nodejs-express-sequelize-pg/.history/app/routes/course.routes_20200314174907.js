module.exports = app => {
  const course = require("../controllers/course.controller.js");
  const checkAuth=require('../../middleware/check-auth');
  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/",checkAuth, course.create);

  // Retrieve all Tutorials
  router.get("/", course.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", course.findOne);

  // Update a Tutorial with id
  router.put("/:id", course.update);

  // Delete a Tutorial with id
  router.delete("/:id", course.delete);

  // Create a new Tutorial
  router.delete("/", course.deleteAll);

  app.use('/api/course', router);
};
