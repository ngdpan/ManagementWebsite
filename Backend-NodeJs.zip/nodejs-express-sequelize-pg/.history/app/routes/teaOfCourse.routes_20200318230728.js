module.exports = app => {
  const teaOfCourse = require("../controllers/teaOfCourse.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new
  router.post("/", [checkAuth,adminVerify],teaOfCourse.create);

  // Retrieve all
  router.get("/", [checkAuth],teaOfCourse.findAll);

  // // Retrieve all published
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single with id
  router.get("/:id", [checkAuth],teaOfCourse.findOne);

  // Update a with id
  router.put("/:id",[checkAuth,adminVerify] ,teaOfCourse.update);

  // Delete a with id
  router.delete("/:id",[checkAuth,adminVerify], teaOfCourse.delete);

  // Delete a new 
  router.delete("/", [checkAuth,adminVerify],teaOfCourse.deleteAll);

  app.use('/api/teacherofcourse', router);
};
