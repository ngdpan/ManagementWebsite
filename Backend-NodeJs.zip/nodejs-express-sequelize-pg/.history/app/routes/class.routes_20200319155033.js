module.exports = app => {
  const class_room = require("../controllers/class.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new 
  router.post("/",[checkAuth], class_room.create);

  // Retrieve all 
  router.get("/",[checkAuth], class_room.findAll);

  // // Retrieve all published 
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single  with id
  router.get("/:id",[checkAuth], class_room.findOne);

  // Update a  with id
  router.put("/:id",[checkAuth,adminVerify], class_room.update);

  // Delete a  with id
  router.delete("/:id",[checkAuth,adminVerify], class_room.delete);

  //Delete
  router.delete("/",[checkAuth,adminVerify], class_room.deleteAll);

  app.use('/api/class', router);
};
