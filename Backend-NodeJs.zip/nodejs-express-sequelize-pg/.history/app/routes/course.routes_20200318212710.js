module.exports = app => {
  const course = require("../controllers/course.controller.js");
  const checkAuth=require('../middleware/check-auth');
  const adminVerify=require('../middleware/admin-verify');
  const teacherVerify=require('../middleware/teacher-verify');
  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/",[checkAuth,adminVerify,teacherVerify], course.create);

  // Retrieve all Tutorials
  router.get("/", [checkAuth,adminVerify,teacherVerify],course.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id",[checkAuth,adminVerify,teacherVerify], course.findOne);

  // Update a Tutorial with id
  router.put("/:id",[checkAuth,adminVerify,teacherVerify], course.update);

  // Delete a Tutorial with id
  router.delete("/:id",[checkAuth,adminVerify,teacherVerify], course.delete);

  // Create a new Tutorial
  router.delete("/",[checkAuth,adminVerify,teacherVerify], course.deleteAll);

  app.use('/api/course', router);
};
