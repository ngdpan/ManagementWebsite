module.exports = app => {
  const class_room = require("../controllers/class.controller.js");
  const checkAuth=require('../middleware/check-auth');
  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/", class_room.create);

  // Retrieve all Tutorials
  router.get("/",checkAuth, class_room.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", class_room.findOne);

  // Update a Tutorial with id
  router.put("/:id", class_room.update);

  // Delete a Tutorial with id
  router.delete("/:id", class_room.delete);

  // Create a new Tutorial
  router.delete("/", class_room.deleteAll);

  app.use('/api/class', router);
};
